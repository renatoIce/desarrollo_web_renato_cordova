import os
import re
import uuid
from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory, jsonify
from werkzeug.utils import secure_filename
from config import Configuracion
from models import base_datos, Miembro, Actividad, Foto, Region, Comuna, Comentario
from sqlalchemy import func

aplicacion = Flask(__name__)
aplicacion.config.from_object(Configuracion)

base_datos.init_app(aplicacion)

def extension_permitida(nombre_archivo):
    return (
        "." in nombre_archivo
        and nombre_archivo.rsplit(".", 1)[1].lower() in aplicacion.config["EXTENSIONES_PERMITIDAS"]
    )

def guardar_archivo(archivo):
    if not archivo or archivo.filename == "":
        return None, None
    if not extension_permitida(archivo.filename):
        return None, None
    nombre_original = secure_filename(archivo.filename)
    extension = nombre_original.rsplit(".", 1)[1].lower()
    nombre_guardado = f"{uuid.uuid4().hex}.{extension}"
    ruta_destino = os.path.join(aplicacion.config["UPLOAD_FOLDER"], nombre_guardado)
    archivo.save(ruta_destino)
    return nombre_guardado, nombre_original

def validar_miembro(nombre, email, tipo, edad_str, telefono, comuna_id_str):
    errores = {}

    if not nombre:
        errores["nombre"] = "El nombre es obligatorio."
    elif not re.match(r"^[a-záéíóúüñA-ZÁÉÍÓÚÜÑ\s]+$", nombre):
        errores["nombre"] = "El nombre solo puede contener letras."
    elif len(nombre) <= 3:
        errores["nombre"] = "Tiene que tener más de 3 letras."

    if not email or "@" not in email:
        errores["email"] = "Email inválido."

    tipos_validos = {"estudiante", "academico", "funcionario"}
    if tipo not in tipos_validos:
        errores["tipomiembro"] = "Tipo de miembro inválido."

    try:
        edad = int(edad_str)
        if edad < 1 or edad > 120:
            errores["edad"] = "Edad inválida (debe ser entre 1 y 120)."
    except (ValueError, TypeError):
        errores["edad"] = "Edad inválida."

    if not re.match(r"^\d{8}$", telefono):
        errores["nrocontacto"] = "Número de contacto inválido (debe tener 8 dígitos)."

    try:
        comuna_id = int(comuna_id_str)
        if not Comuna.query.get(comuna_id):
            errores["comuna"] = "Comuna inválida."
    except (ValueError, TypeError):
        errores["comuna"] = "Debe seleccionar una comuna."

    return errores

def validar_actividades(tipos_act, dias_act, horas_act, enlaces_act, nombres_act, descripciones_act):
    tipos_validos = {"deportiva", "artistica", "tecnologica", "social", "recreativa"}
    dias_validos = {"lunes", "martes", "miercoles", "jueves", "viernes", "sabado", "domingo"}

    errores_actividades = []
    actividades_validas = []

    for indice, (tipo, dia, horas_str, enlace, nombre_act, descripcion_act) in enumerate(
        zip(tipos_act, dias_act, horas_act, enlaces_act, nombres_act, descripciones_act)
    ):
        error_actual = {}
        tipo          = tipo.strip()
        dia           = dia.strip()
        horas_str     = horas_str.strip()
        enlace        = enlace.strip()
        nombre_act    = nombre_act.strip()
        descripcion_act = descripcion_act.strip()

        if not nombre_act:
            error_actual["nombre"] = "El nombre de la actividad es obligatorio."
        elif len(nombre_act) > 45:
            error_actual["nombre"] = "El nombre no puede tener más de 45 caracteres."

        if tipo not in tipos_validos:
            error_actual["tipo"] = "Tipo de actividad inválido."
        if dia not in dias_validos:
            error_actual["dia"] = "Día inválido."

        try:
            cantidad_horas = int(horas_str)
            if cantidad_horas < 1 or cantidad_horas > 40:
                error_actual["horas"] = "Las horas deben estar entre 1 y 40."
        except (ValueError, TypeError):
            error_actual["horas"] = "Horas inválidas."
            cantidad_horas = None

        if enlace and not enlace.startswith(("http://", "https://")):
            error_actual["enlace"] = "El enlace debe comenzar con http:// o https://"

        if error_actual:
            errores_actividades.append((indice, error_actual))
        else:
            actividades_validas.append({
                "tipo": tipo,
                "dia": dia,
                "horas": cantidad_horas,
                "enlace": enlace or None,
                "nombre": nombre_act,
                "descripcion": descripcion_act or None,
                "indice_archivo": indice,
            })

    return errores_actividades, actividades_validas

@aplicacion.route("/")
def portada():
    ultimos_miembros = Miembro.query.order_by(Miembro.fecha_registro.desc()).limit(5).all()
    return render_template("index.html", ultimos_miembros=ultimos_miembros)


@aplicacion.route("/registro", methods=["GET", "POST"])
def registro():
    errores = {}
    datos = {}
    regiones = Region.query.order_by(Region.nombre).all()

    if request.method == "POST":
        nombre = request.form.get("nombre", "").strip()
        email = request.form.get("email", "").strip()
        tipo = request.form.get("tipomiembro", "").strip()
        edad_str = request.form.get("edad", "").strip()
        telefono = request.form.get("numerocontacto", "").strip()
        comuna_id_str = request.form.get("comuna_id", "").strip()

        datos = {
            "nombre": nombre,
            "email": email,
            "tipo": tipo,
            "edad": edad_str,
            "nrocontacto": telefono,
            "comuna_id": comuna_id_str,
            "region_id": request.form.get("region_id", ""),
        }

        errores = validar_miembro(nombre, email, tipo, edad_str, telefono, comuna_id_str)

        tipos_act         = request.form.getlist("tipo_act[]")
        dias_act          = request.form.getlist("dia_act[]")
        horas_act         = request.form.getlist("horas_act[]")
        enlaces_act       = request.form.getlist("enlace_act[]")
        nombres_act       = request.form.getlist("nombre_act[]")
        descripciones_act = request.form.getlist("descripcion_act[]")
        archivos          = request.files.getlist("archivo_act[]")

        if not tipos_act:
            errores["actividades"] = "Debe registrar al menos una actividad."
            errores_actividades = []
            actividades_validas = []
        else:
            errores_actividades, actividades_validas = validar_actividades(
                tipos_act, dias_act, horas_act, enlaces_act, nombres_act, descripciones_act
            )
            if errores_actividades:
                errores["actividades_detalle"] = errores_actividades

        if not errores:
            nuevo_miembro = Miembro(
                nombre=nombre,
                email=email,
                tipo=tipo,
                edad=int(edad_str),
                telefono=telefono,
                comuna_id=int(comuna_id_str),
            )
            base_datos.session.add(nuevo_miembro)
            base_datos.session.flush()

            for datos_actividad in actividades_validas:
                nueva_actividad = Actividad(
                    miembro_id=nuevo_miembro.id,
                    tipo=datos_actividad["tipo"],
                    dia=datos_actividad["dia"],
                    horas=datos_actividad["horas"],
                    enlace=datos_actividad["enlace"],
                    nombre=datos_actividad["nombre"],
                    descripcion=datos_actividad["descripcion"],
                )
                base_datos.session.add(nueva_actividad)
                base_datos.session.flush()

                indice_archivo = datos_actividad["indice_archivo"]
                if indice_archivo < len(archivos):
                    archivo_subido = archivos[indice_archivo]
                    nombre_guardado, nombre_original = guardar_archivo(archivo_subido)
                    if nombre_guardado:
                        nueva_foto = Foto(
                            actividad_id=nueva_actividad.id,
                            ruta_archivo=nombre_guardado,
                            nombre_archivo=nombre_original,
                        )
                        base_datos.session.add(nueva_foto)

            base_datos.session.commit()
            flash("Miembro registrado exitosamente.", "exito")
            return redirect(url_for("portada"))

    return render_template("registro.html", errores=errores, datos=datos, regiones=regiones)


@aplicacion.route("/miembros")
def listado():
    pagina_actual = request.args.get("pagina", 1, type=int)
    miembros_por_pagina = 5
    paginacion = Miembro.query.order_by(Miembro.fecha_registro.desc()).paginate(
        page=pagina_actual, per_page=miembros_por_pagina, error_out=False
    )
    return render_template("listado.html", paginacion=paginacion)


@aplicacion.route("/miembros/<int:id_miembro>")
def detalle(id_miembro):
    miembro = Miembro.query.get_or_404(id_miembro)
    return render_template("detalle.html", miembro=miembro)


@aplicacion.route("/uploads/<nombre_archivo>")
def archivo_subido(nombre_archivo):
    return send_from_directory(aplicacion.config["UPLOAD_FOLDER"], nombre_archivo)


@aplicacion.route("/api/comunas/<int:id_region>")
def obtener_comunas(id_region):
    comunas = Comuna.query.filter_by(region_id=id_region).order_by(Comuna.nombre).all()
    resultado = [{"id": c.id, "nombre": c.nombre} for c in comunas]
    return jsonify(resultado)


@aplicacion.route("/api/comentarios/<int:id_actividad>")
def obtener_comentarios(id_actividad):
    actividad = Actividad.query.get_or_404(id_actividad)
    comentarios = Comentario.query.filter_by(actividad_id=id_actividad).order_by(Comentario.fecha.asc()).all()
    resultado = [
        {
            "nombre": c.nombre,
            "texto": c.texto,
            "fecha": c.fecha.strftime("%d/%m/%Y %H:%M"),
        }
        for c in comentarios
    ]
    return jsonify(resultado)


@aplicacion.route("/api/comentarios/<int:id_actividad>", methods=["POST"])
def agregar_comentario(id_actividad):
    actividad = Actividad.query.get_or_404(id_actividad)
    datos = request.get_json()

    nombre = (datos.get("nombre") or "").strip()
    texto = (datos.get("texto") or "").strip()

    errores = {}
    if len(nombre) < 3 or len(nombre) > 80:
        errores["nombre"] = "El nombre debe tener entre 3 y 80 caracteres."
    if len(texto) < 5:
        errores["texto"] = "El comentario debe tener al menos 5 caracteres."

    if errores:
        return jsonify({"error": errores}), 400

    nuevo_comentario = Comentario(
        nombre=nombre,
        texto=texto,
        actividad_id=id_actividad,
    )
    base_datos.session.add(nuevo_comentario)
    base_datos.session.commit()

    return jsonify({
        "nombre": nuevo_comentario.nombre,
        "texto": nuevo_comentario.texto,
        "fecha": nuevo_comentario.fecha.strftime("%d/%m/%Y %H:%M"),
    }), 201



@aplicacion.route("/api/estadisticas/miembros_por_dia")
def estadisticas_miembros_por_dia():
    resultados = (
        base_datos.session.query(
            func.date(Miembro.fecha_registro).label("dia"),
            func.count(Miembro.id).label("cantidad")
        )
        .group_by(func.date(Miembro.fecha_registro))
        .order_by(func.date(Miembro.fecha_registro))
        .all()
    )
    datos = [{"dia": str(r.dia), "cantidad": r.cantidad} for r in resultados]
    return jsonify(datos)


@aplicacion.route("/api/estadisticas/actividades_por_tipo")
def estadisticas_actividades_por_tipo():
    resultados = (
        base_datos.session.query(
            Actividad.tipo,
            func.count(Actividad.id).label("cantidad")
        )
        .group_by(Actividad.tipo)
        .all()
    )
    datos = [{"tipo": r.tipo, "cantidad": r.cantidad} for r in resultados]
    return jsonify(datos)


@aplicacion.route("/api/estadisticas/actividades_por_comuna")
def estadisticas_actividades_por_comuna():
    resultados = (
        base_datos.session.query(
            Comuna.nombre.label("comuna"),
            func.count(Actividad.id).label("cantidad")
        )
        .join(Miembro, Miembro.comuna_id == Comuna.id)
        .join(Actividad, Actividad.miembro_id == Miembro.id)
        .group_by(Comuna.nombre)
        .order_by(func.count(Actividad.id).desc())
        .all()
    )
    datos = [{"comuna": r.comuna, "cantidad": r.cantidad} for r in resultados]
    return jsonify(datos)


@aplicacion.route("/estadisticas")
def estadisticas():
    return render_template("estadisticas.html")


if __name__ == "__main__":
    with aplicacion.app_context():
        base_datos.create_all()
    aplicacion.run(debug=True)
