package cl.uchile.tarea4.repositorios;

import cl.uchile.tarea4.entidades.Actividad;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface RepositorioActividad extends JpaRepository<Actividad, Integer> {

    @Query("SELECT a FROM Actividad a JOIN a.miembro m JOIN m.comuna c " +
           "WHERE a.nombre LIKE %:patron% " +
           "OR a.descripcion LIKE %:patron% " +
           "OR c.nombre LIKE %:patron%")
    List<Actividad> buscarPorPatron(@Param("patron") String patron);
}
