package cl.uchile.tarea4.repositorios;

import cl.uchile.tarea4.entidades.Nota;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.Optional;

public interface RepositorioNota extends JpaRepository<Nota, Integer> {

    @Query("SELECT n FROM Nota n WHERE n.actividadId = :actividadId ORDER BY n.id DESC")
    Optional<Nota> obtenerUltimaNota(@Param("actividadId") Integer actividadId);
}
