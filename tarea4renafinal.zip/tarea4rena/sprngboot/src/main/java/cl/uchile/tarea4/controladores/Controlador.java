package cl.uchile.tarea4.controladores;

import cl.uchile.tarea4.entidades.Actividad;
import cl.uchile.tarea4.entidades.Nota;
import cl.uchile.tarea4.repositorios.RepositorioActividad;
import cl.uchile.tarea4.repositorios.RepositorioNota;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@CrossOrigin(origins = "*")
public class Controlador {

    @Autowired
    private RepositorioActividad repositorioActividad;

    @Autowired
    private RepositorioNota repositorioNota;

    
    @GetMapping("/api/buscar")
    public ResponseEntity<List<Map<String, Object>>> buscar(@RequestParam String patron) {

        if (patron == null || patron.trim().length() < 3) {
            return ResponseEntity.badRequest().build();
        }

        List<Actividad> actividades = repositorioActividad.buscarPorPatron(patron.trim());
        List<Map<String, Object>> resultado = new ArrayList<>();

        for (Actividad actividad : actividades) {
            Map<String, Object> item = new HashMap<>();
            item.put("id", actividad.getId());
            item.put("nombre", actividad.getNombre());
            item.put("descripcion", actividad.getDescripcion());
            item.put("tipo", actividad.getTipo());
            item.put("dia", actividad.getDia());

            //datos miembro
            if (actividad.getMiembro() != null) {
                item.put("nombreMiembro", actividad.getMiembro().getNombre());
                //datos comuna
                if (actividad.getMiembro().getComuna() != null) {
                    item.put("comuna", actividad.getMiembro().getComuna().getNombre());
                } else {
                    item.put("comuna", "-");
                }
            } else {
                item.put("nombreMiembro", "-");
                item.put("comuna", "-");
            }

            
            Optional<Nota> ultimaNota = repositorioNota.obtenerUltimaNota(actividad.getId());
            item.put("nota", ultimaNota.map(n -> (Object) n.getNota()).orElse("-"));

            resultado.add(item);
        }

        return ResponseEntity.ok(resultado);
    }

    
    @PostMapping("/api/notas/{idActividad}")
    public ResponseEntity<Map<String, Object>> agregarNota(
            @PathVariable Integer idActividad,
            @RequestBody Map<String, Object> cuerpo) {

        Object valorNota = cuerpo.get("nota");
        if (valorNota == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "Nota requerida."));
        }

        int notaValor;
        try {
            notaValor = Integer.parseInt(valorNota.toString());
        } catch (NumberFormatException e) {
            return ResponseEntity.badRequest().body(Map.of("error", "La nota debe ser un número entero."));
        }

        if (notaValor < 1 || notaValor > 7) {
            return ResponseEntity.badRequest().body(Map.of("error", "La nota debe estar entre 1 y 7."));
        }

        
        if (!repositorioActividad.existsById(idActividad)) {
            return ResponseEntity.notFound().build();
        }

        Nota nuevaNota = new Nota();
        nuevaNota.setActividadId(idActividad);
        nuevaNota.setNota(notaValor);
        repositorioNota.save(nuevaNota);

        return ResponseEntity.ok(Map.of(
            "nota", notaValor,
            "mensaje", "Nota agregada exitosamente."
        ));
    }
}
