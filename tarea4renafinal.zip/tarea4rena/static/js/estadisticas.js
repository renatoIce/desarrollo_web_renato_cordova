// grafico lineas
fetch("/api/estadisticas/miembros_por_dia")
    .then(function(respuesta) { return respuesta.json(); })
    .then(function(datos) {
        var categorias = datos.map(function(d) { return d.dia; });
        var valores    = datos.map(function(d) { return d.cantidad; });

        Highcharts.chart("grafico-lineas", {
            chart:  { type: "line" },
            title:  { text: "Miembros registrados por día" },
            xAxis:  { categories: categorias, title: { text: "Día" } },
            yAxis:  { title: { text: "Cantidad de miembros" }, allowDecimals: false },
            series: [{ name: "Miembros", data: valores }],
            credits: { enabled: false }
        });
    });

//grafico torta
fetch("/api/estadisticas/actividades_por_tipo")
    .then(function(respuesta) { return respuesta.json(); })
    .then(function(datos) {
        var serieData = datos.map(function(d) {
            return { name: d.tipo, y: d.cantidad };
        });

        Highcharts.chart("grafico-torta", {
            chart:  { type: "pie" },
            title:  { text: "Actividades por tipo" },
            series: [{ name: "Actividades", colorByPoint: true, data: serieData }],
            credits: { enabled: false }
        });
    });

//grafico barras
fetch("/api/estadisticas/actividades_por_comuna")
    .then(function(respuesta) { return respuesta.json(); })
    .then(function(datos) {
        var categorias = datos.map(function(d) { return d.comuna; });
        var valores    = datos.map(function(d) { return d.cantidad; });

        Highcharts.chart("grafico-barras", {
            chart:  { type: "bar" },
            title:  { text: "Actividades por comuna" },
            xAxis:  { categories: categorias, title: { text: "Comuna" } },
            yAxis:  { title: { text: "Total de actividades" }, allowDecimals: false },
            series: [{ name: "Actividades", data: valores }],
            credits: { enabled: false }
        });
    });
