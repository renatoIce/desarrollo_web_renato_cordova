let contadorActividades = 0;

function agregarActividad() {
    contadorActividades++;
    const indice = contadorActividades;

    const contenedor = document.getElementById("contenedor-actividades");

    const divActividad = document.createElement("div");
    divActividad.classList.add("actividad-item");
    divActividad.id = "actividad-" + indice;

    divActividad.innerHTML = `
        <h3>Actividad ${indice}</h3>

        <div>
            <label>Tipo:</label>
            <select name="tipo_act[]" id="tipo-act-${indice}">
                <option value="">-- Seleccione --</option>
                <option value="deportiva">Deportiva</option>
                <option value="artistica">Artística</option>
                <option value="tecnologica">Tecnológica</option>
                <option value="social">Social</option>
                <option value="recreativa">Recreativa</option>
            </select>
            <span class="error" id="error-tipo-${indice}"></span>
        </div>

        <div>
            <label>Día:</label>
            <select name="dia_act[]" id="dia-act-${indice}">
                <option value="">-- Seleccione --</option>
                <option value="lunes">Lunes</option>
                <option value="martes">Martes</option>
                <option value="miercoles">Miércoles</option>
                <option value="jueves">Jueves</option>
                <option value="viernes">Viernes</option>
                <option value="sabado">Sábado</option>
                <option value="domingo">Domingo</option>
            </select>
            <span class="error" id="error-dia-${indice}"></span>
        </div>

        <div>
            <label>Horas semanales:</label>
            <input type="number" name="horas_act[]" id="horas-act-${indice}" min="1" max="40">
            <span class="error" id="error-horas-${indice}"></span>
        </div>

        <div>
            <label>Nombre de la actividad:</label>
            <input type="text" name="nombre_act[]" id="nombre-act-${indice}" maxlength="45" placeholder="Ej: Taller de pintura">
            <span class="error" id="error-nombre-act-${indice}"></span>
        </div>

        <div>
            <label>Descripción:</label>
            <textarea name="descripcion_act[]" id="descripcion-act-${indice}" rows="3" cols="40" placeholder="Descripción de la actividad..."></textarea>
        </div>

        <div>
            <label>Foto o Video:</label>
            <input type="file" name="archivo_act[]" id="archivo-act-${indice}" accept="image/*, video/*">
        </div>

        <div>
            <label>Enlace:</label>
            <input type="url" name="enlace_act[]" id="enlace-act-${indice}" placeholder="https://...">
            <span class="error" id="error-enlace-${indice}"></span>
        </div>

        <button type="button" onclick="eliminarActividad(${indice})">Eliminar actividad</button>
    `;

    contenedor.appendChild(divActividad);
    actualizarContador();
}

function eliminarActividad(indice) {
    const div = document.getElementById("actividad-" + indice);
    if (div) {
        div.remove();
        actualizarContador();
    }
}

function actualizarContador() {
    const total = document.querySelectorAll(".actividad-item").length;
    const contador = document.getElementById("contador-actividades");
    if (contador) {
        contador.textContent = total;
    }
}

function validarFormulario() {
    let valido = true;

    //validar miembro
    const nombre = document.getElementById("nombre").value.trim();
    const email = document.getElementById("email").value.trim();
    const tipomiembro = document.getElementById("tipomiembro").value;
    const edad = parseInt(document.getElementById("edad").value);
    const nrocontacto = document.getElementById("numerocontacto").value.trim();

    //limpiar errores
    document.getElementById("error-nombre").textContent = "";
    document.getElementById("error-email").textContent = "";
    document.getElementById("error-miembro").textContent = "";
    document.getElementById("error-edad").textContent = "";
    document.getElementById("error-nrocontacto").textContent = "";

    if (nombre === "") {
        document.getElementById("error-nombre").textContent = "El nombre es obligatorio.";
        valido = false;
    } else if (!/^[a-záéíóúüñA-ZÁÉÍÓÚÜÑ\s]+$/.test(nombre)) {
        document.getElementById("error-nombre").textContent = "El nombre solo puede contener letras.";
        valido = false;
    } else if (nombre.length <= 3) {
        document.getElementById("error-nombre").textContent = "Tiene que tener más de 3 letras.";
        valido = false;
    }

    if (!email.includes("@")) {
        document.getElementById("error-email").textContent = "Email inválido.";
        valido = false;
    }

    if (tipomiembro === "") {
        document.getElementById("error-miembro").textContent = "Debe seleccionar un tipo de miembro.";
        valido = false;
    }

    if (isNaN(edad) || edad < 1 || edad > 120) {
        document.getElementById("error-edad").textContent = "Edad inválida (debe ser entre 1 y 120).";
        valido = false;
    }

    if (!/^\d{8}$/.test(nrocontacto)) {
        document.getElementById("error-nrocontacto").textContent = "Debe tener exactamente 8 dígitos.";
        valido = false;
    }

    const actividades = document.querySelectorAll(".actividad-item");
    if (actividades.length === 0) {
        alert("Debe agregar al menos una actividad.");
        valido = false;
    }

    actividades.forEach(function(div) {
        const idActividad = div.id.replace("actividad-", "");

        const tipo= document.getElementById("tipo-act-"  + idActividad).value;
        const dia= document.getElementById("dia-act-"   + idActividad).value;
        const horas= parseInt(document.getElementById("horas-act-" + idActividad).value);
        const enlace= document.getElementById("enlace-act-" + idActividad).value.trim();

        document.getElementById("error-tipo-"  + idActividad).textContent = "";
        document.getElementById("error-dia-"   + idActividad).textContent = "";
        document.getElementById("error-horas-" + idActividad).textContent = "";
        document.getElementById("error-enlace-" + idActividad).textContent = "";
        document.getElementById("error-nombre-act-" + idActividad).textContent = "";

        const nombreAct = document.getElementById("nombre-act-" + idActividad).value.trim();
        if (nombreAct === "") {
            document.getElementById("error-nombre-act-" + idActividad).textContent = "El nombre de la actividad es obligatorio.";
            valido = false;
        } else if (nombreAct.length > 45) {
            document.getElementById("error-nombre-act-" + idActividad).textContent = "El nombre no puede tener más de 45 caracteres.";
            valido = false;
        }

        if (tipo === "") {
            document.getElementById("error-tipo-" + idActividad).textContent = "Debe seleccionar un tipo.";
            valido = false;
        }
        if (dia === "") {
            document.getElementById("error-dia-" + idActividad).textContent = "Debe seleccionar un día.";
            valido = false;
        }
        if (isNaN(horas) || horas < 1 || horas > 40) {
            document.getElementById("error-horas-" + idActividad).textContent = "Ingrese un número entre 1 y 40.";
            valido = false;
        }
        if (enlace !== "" && !enlace.startsWith("http://") && !enlace.startsWith("https://")) {
            document.getElementById("error-enlace-" + idActividad).textContent = "El enlace debe comenzar con http:// o https://";
            valido = false;
        }
    });

    return valido;
}

// agregar act por default
document.addEventListener("DOMContentLoaded", function() {
    agregarActividad();

    document.getElementById("formulario-registro").addEventListener("submit", function(evento) {
        if (!validarFormulario()) {
            evento.preventDefault();
        }
    });
});

//agregado de region-comuna 

document.addEventListener("DOMContentLoaded", function() {
    var selectorRegion = document.getElementById("region_id");
    var selectorComuna = document.getElementById("comuna_id");

    if (selectorRegion) {
        selectorRegion.addEventListener("change", function() {
            var idRegion = this.value;
            selectorComuna.innerHTML = "<option value=''>-- Selecciona una comuna --</option>";

            if (!idRegion) return;

            fetch("/api/comunas/" + idRegion)
                .then(function(respuesta) { return respuesta.json(); })
                .then(function(comunas) {
                    comunas.forEach(function(comuna) {
                        var opcion = document.createElement("option");
                        opcion.value = comuna.id;
                        opcion.textContent = comuna.nombre;
                        if (String(comuna.id) === comunaSeleccionada) {
                            opcion.selected = true;
                        }
                        selectorComuna.appendChild(opcion);
                    });
                });
        });

    
        if (regionSeleccionada) {
            selectorRegion.value = regionSeleccionada;
            selectorRegion.dispatchEvent(new Event("change"));
        }
    }
});
