import os

class Configuracion:
    # db
    SQLALCHEMY_DATABASE_URI = (
        "mysql+pymysql://cc5002:programacionweb@localhost:3306/tarea2"
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # carpeta archivos
    UPLOAD_FOLDER = os.path.join(os.path.dirname(__file__), "uploads")

    EXTENSIONES_PERMITIDAS = {"png", "jpg", "jpeg", "gif", "webp", "mp4", "mov", "avi"}

    # tamaño max 50 mb
    MAX_CONTENT_LENGTH = 50 * 1024 * 1024

    SECRET_KEY = "clave_secreta_tarea2_cc5002"
