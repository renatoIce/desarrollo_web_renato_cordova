package cl.uchile.tarea4.repositorios;

import cl.uchile.tarea4.entidades.Log;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface RepositorioLog extends JpaRepository<Log, Long> {

    List<Log> findAllByOrderByFechaDesc();
}
