package cl.uchile.tarea4.entidades;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "actividad")
public class Actividad {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "miembro_id")
    private Integer miembroId;

    @Column(name = "tipo")
    private String tipo;

    @Column(name = "dia")
    private String dia;

    @Column(name = "horas")
    private Integer horas;

    @Column(name = "enlace")
    private String enlace;

    @Column(name = "nombre")
    private String nombre;

    @Column(name = "descripcion")
    private String descripcion;

    @ManyToOne
    @JoinColumn(name = "miembro_id", insertable = false, updatable = false)
    private Miembro miembro;

    @OneToMany(mappedBy = "actividad", fetch = FetchType.LAZY)
    private java.util.List<Foto> fotos;

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public Integer getMiembroId() { return miembroId; }
    public void setMiembroId(Integer miembroId) { this.miembroId = miembroId; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getDia() { return dia; }
    public void setDia(String dia) { this.dia = dia; }

    public Integer getHoras() { return horas; }
    public void setHoras(Integer horas) { this.horas = horas; }

    public String getEnlace() { return enlace; }
    public void setEnlace(String enlace) { this.enlace = enlace; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public Miembro getMiembro() { return miembro; }
    public void setMiembro(Miembro miembro) { this.miembro = miembro; }
}
