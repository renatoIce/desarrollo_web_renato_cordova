package cl.uchile.tarea4.controladores;

import cl.uchile.tarea4.entidades.Foto;
import cl.uchile.tarea4.entidades.Log;
import cl.uchile.tarea4.repositorios.RepositorioFoto;
import cl.uchile.tarea4.repositorios.RepositorioLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.MediaType;

import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Controller
public class ControladorAdmin {

    @Value("${app.uploads.path}")
    private String rutaUploads;

    @Autowired
    private RepositorioFoto repositorioFoto;

    @Autowired
    private RepositorioLog repositorioLog;

    @GetMapping("/uploads/{nombreArchivo:.+}")
    @ResponseBody
    public ResponseEntity<Resource> servirArchivo(@PathVariable String nombreArchivo) {
        try {
            Path ruta = Paths.get(rutaUploads).resolve(nombreArchivo);
            Resource recurso = new UrlResource(ruta.toUri());
            if (recurso.exists()) {
                return ResponseEntity.ok()
                    .contentType(MediaType.IMAGE_JPEG)
                    .body(recurso);
            }
            return ResponseEntity.notFound().build();
        } catch (MalformedURLException e) {
            return ResponseEntity.badRequest().build();
        }
    }

    //pag login
    @GetMapping("/login")
    public String paginaLogin() {
        return "login";
    }

    //admin fotos
    @GetMapping("/admin-fotos")
    public String adminFotos(Model modelo) {
        List<Foto> fotos = repositorioFoto.findAllByOrderByIdDesc();
        modelo.addAttribute("fotos", fotos);
        return "admin-fotos";
    }

    @PostMapping("/api/admin/eliminar-foto/{idFoto}")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> eliminarFoto(
            @PathVariable Integer idFoto,
            @RequestBody Map<String, String> cuerpo) {

        String motivo = cuerpo.get("motivo");
        if (motivo == null || motivo.trim().length() < 5 || motivo.trim().length() > 200) {
            return ResponseEntity.badRequest().body(
                Map.of("error", "El motivo debe tener entre 5 y 200 caracteres.")
            );
        }

        Optional<Foto> fotoOpt = repositorioFoto.findById(idFoto);
        if (fotoOpt.isEmpty()) {
            return ResponseEntity.notFound().build();
        }

        Foto foto = fotoOpt.get();
        foto.setEliminada(1);
        repositorioFoto.save(foto);

        //registrar en log
        Log registro = new Log();
        registro.setFecha(LocalDateTime.now());
        registro.setMensaje("foto eliminada de ID " + idFoto + " por admin, motivo: " + motivo.trim());
        repositorioLog.save(registro);

        return ResponseEntity.ok(Map.of("mensaje", "Foto marcada como eliminada."));
    }

    // mensajes log
    @GetMapping("/mensajes-log")
    public String mensajesLog(Model modelo) {
        List<Log> logs = repositorioLog.findAllByOrderByFechaDesc();
        modelo.addAttribute("logs", logs);
        return "mensajes-log";
    }

    // estadisticas foto
    @GetMapping("/estadistica-fotos")
    public String estadisticaFotos() {
        return "estadistica-fotos";
    }

    @GetMapping("/api/estadistica-fotos")
    @ResponseBody
    public ResponseEntity<Map<String, Object>> datoEstadisticaFotos() {
        long vigentes  = repositorioFoto.countByEliminada(0);
        long eliminadas = repositorioFoto.countByEliminada(1);
        return ResponseEntity.ok(Map.of(
            "vigentes", vigentes,
            "eliminadas", eliminadas
        ));
    }
}
