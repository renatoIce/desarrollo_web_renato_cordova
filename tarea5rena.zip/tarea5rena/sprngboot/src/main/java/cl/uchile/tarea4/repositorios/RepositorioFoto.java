package cl.uchile.tarea4.repositorios;

import cl.uchile.tarea4.entidades.Foto;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface RepositorioFoto extends JpaRepository<Foto, Integer> {

    List<Foto> findAllByOrderByIdDesc();

    long countByEliminada(Integer eliminada);
}
