package cl.uchile.tarea4.configuracion;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class ConfiguracionSeguridad {

    @Bean
    public PasswordEncoder codificadorContrasena() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public UserDetailsService usuariosEnMemoria(PasswordEncoder codificador) {
        var admin = User.builder()
            .username("cc5002")
            .password(codificador.encode("examen"))
            .roles("ADMIN", "AUDITOR")
            .build();

        var auditor = User.builder()
            .username("auditor")
            .password(codificador.encode("log-auditor"))
            .roles("AUDITOR")
            .build();

        return new InMemoryUserDetailsManager(admin, auditor);
    }

    @Bean
    public SecurityFilterChain cadenaFiltros(HttpSecurity http) throws Exception {
        http
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/admin-fotos/**").hasRole("ADMIN")
                .requestMatchers("/mensajes-log/**").hasAnyRole("ADMIN", "AUDITOR")
                .requestMatchers("/estadistica-fotos/**", "/api/**", "/", "/css/**", "/js/**").permitAll()
                .anyRequest().permitAll()
            )
            .formLogin(form -> form
                .loginPage("/login")
                .permitAll()
            )
            .logout(logout -> logout
                .logoutSuccessUrl("/")
                .permitAll()
            )
            .csrf(csrf -> csrf.disable());

        return http.build();
    }
}
