var temporizador = null;

document.getElementById("campoBusqueda").addEventListener("input", function() {
    var patron = this.value.trim();

    clearTimeout(temporizador);

    if (patron.length < 3) {
        document.getElementById("contenedorResultados").innerHTML = "";
        document.getElementById("mensajeBusqueda").textContent = "";
        return;
    }

    // temporizador de 300ms después de que el usuario deja de escribir
    temporizador = setTimeout(function() {
        buscarActividades(patron);
    }, 300);
});

function buscarActividades(patron) {
    document.getElementById("mensajeBusqueda").textContent = "Buscando...";

    fetch("/api/buscar?patron=" + encodeURIComponent(patron))
        .then(function(respuesta) { return respuesta.json(); })
        .then(function(resultados) {
            if (resultados.length === 0) {
                document.getElementById("mensajeBusqueda").textContent = "No se encontraron resultados.";
                document.getElementById("contenedorResultados").innerHTML = "";
                return;
            }

            document.getElementById("mensajeBusqueda").textContent = resultados.length + " resultado(s) encontrado(s).";
            mostrarResultados(resultados, patron);
        })
        .catch(function() {
            document.getElementById("mensajeBusqueda").textContent = "Error al realizar la búsqueda.";
        });
}

function resaltar(texto, patron) {
    if (!texto) return "-";
    var regex = new RegExp("(" + patron.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + ")", "gi");
    return texto.replace(regex, "<mark class='resaltado'>$1</mark>");
}

function mostrarResultados(resultados, patron) {
    var html = "<table>";
    html += "<thead><tr>";
    html += "<th>Nombre actividad</th>";
    html += "<th>Descripción</th>";
    html += "<th>Tipo</th>";
    html += "<th>Día</th>";
    html += "<th>Miembro</th>";
    html += "<th>Comuna</th>";
    html += "<th>Nota</th>";
    html += "<th>Acción</th>";
    html += "</tr></thead><tbody>";

    resultados.forEach(function(actividad) {
        html += "<tr id='fila-" + actividad.id + "'>";
        html += "<td>" + resaltar(actividad.nombre, patron) + "</td>";
        html += "<td>" + resaltar(actividad.descripcion, patron) + "</td>";
        html += "<td>" + actividad.tipo + "</td>";
        html += "<td>" + actividad.dia + "</td>";
        html += "<td>" + actividad.nombreMiembro + "</td>";
        html += "<td>" + resaltar(actividad.comuna, patron) + "</td>";
        html += "<td id='nota-" + actividad.id + "'>" + actividad.nota + "</td>";
        html += "<td>";
        html += "<select id='select-nota-" + actividad.id + "'>";
        html += "<option value=''>-</option>";
        for (var i = 1; i <= 7; i++) {
            html += "<option value='" + i + "'>" + i + "</option>";
        }
        html += "</select>";
        html += "<button class='btn-evaluar' onclick='evaluar(" + actividad.id + ")'>Evaluar</button>";
        html += "<span class='error' id='error-nota-" + actividad.id + "'></span>";
        html += "</td>";
        html += "</tr>";
    });

    html += "</tbody></table>";
    document.getElementById("contenedorResultados").innerHTML = html;
}

function evaluar(idActividad) {
    var selector = document.getElementById("select-nota-" + idActividad);
    var errorSpan = document.getElementById("error-nota-" + idActividad);
    var valorNota = selector.value;

    errorSpan.textContent = "";

    if (valorNota === "") {
        errorSpan.textContent = "Debe seleccionar una nota.";
        return;
    }

    var notaNum = parseInt(valorNota);
    if (isNaN(notaNum) || notaNum < 1 || notaNum > 7) {
        errorSpan.textContent = "La nota debe estar entre 1 y 7.";
        return;
    }

    fetch("/api/notas/" + idActividad, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nota: notaNum })
    })
    .then(function(respuesta) { return respuesta.json(); })
    .then(function(datos) {
        if (datos.error) {
            errorSpan.textContent = datos.error;
            return;
        }
        // actualizacion nota 
        document.getElementById("nota-" + idActividad).textContent = datos.nota;
        selector.value = "";
    })
    .catch(function() {
        errorSpan.textContent = "Error al guardar la nota.";
    });
}
