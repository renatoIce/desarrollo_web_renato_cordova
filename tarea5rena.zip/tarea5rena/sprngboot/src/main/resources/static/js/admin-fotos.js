function solicitarMotivo(idFoto) {
    document.getElementById("form-motivo-" + idFoto).style.display = "block";
}

function cancelarEliminar(idFoto) {
    document.getElementById("form-motivo-" + idFoto).style.display = "none";
    document.getElementById("error-motivo-" + idFoto).textContent = "";
    document.getElementById("motivo-" + idFoto).value = "";
}

function confirmarEliminar(idFoto) {
    var motivo = document.getElementById("motivo-" + idFoto).value.trim();
    var errorSpan = document.getElementById("error-motivo-" + idFoto);

    errorSpan.textContent = "";

    if (motivo.length < 5 || motivo.length > 200) {
        errorSpan.textContent = "El motivo debe tener entre 5 y 200 caracteres.";
        return;
    }

    fetch("/api/admin/eliminar-foto/" + idFoto, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ motivo: motivo })
    })
    .then(function(respuesta) { return respuesta.json(); })
    .then(function(datos) {
        if (datos.error) {
            errorSpan.textContent = datos.error;
            return;
        }
        document.getElementById("form-motivo-" + idFoto).style.display = "none";
        document.getElementById("exito-" + idFoto).style.display = "block";
    })
    .catch(function() {
        errorSpan.textContent = "Error al procesar la eliminación.";
    });
}
