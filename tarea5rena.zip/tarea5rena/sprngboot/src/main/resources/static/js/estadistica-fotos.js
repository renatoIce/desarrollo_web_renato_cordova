fetch("/api/estadistica-fotos")
    .then(function(respuesta) { return respuesta.json(); })
    .then(function(datos) {
        Highcharts.chart("grafico-fotos", {
            chart: { type: "pie" },
            title: { text: "Estado de Fotos" },
            series: [{
                name: "Fotos",
                colorByPoint: true,
                data: [
                    { name: "Vigentes", y: datos.vigentes },
                    { name: "Eliminadas", y: datos.eliminadas }
                ]
            }],
            credits: { enabled: false }
        });
    });
