from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

base_datos= SQLAlchemy()


class Miembro(base_datos.Model):
    __tablename__ = "miembro"

    id = base_datos.Column(base_datos.Integer, primary_key=True, autoincrement=True)
    nombre = base_datos.Column(base_datos.String(255), nullable=False)
    email = base_datos.Column(base_datos.String(80), nullable=False)
    telefono= base_datos.Column(base_datos.String(15), nullable=False)
    tipo= base_datos.Column(base_datos.String(20), nullable=False)
    edad= base_datos.Column(base_datos.Integer, nullable=False)
    fecha_registro= base_datos.Column(base_datos.DateTime, default=datetime.now, nullable=False)

    actividades= base_datos.relationship("Actividad", backref="miembro", lazy=True, cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Miembro {self.nombre}>"


class Actividad(base_datos.Model):
    __tablename__= "actividad"

    id = base_datos.Column(base_datos.Integer, primary_key=True, autoincrement=True)
    miembro_id= base_datos.Column(base_datos.Integer, base_datos.ForeignKey("miembro.id"), nullable=False)
    tipo= base_datos.Column(base_datos.String(20), nullable=False)
    dia= base_datos.Column(base_datos.String(15), nullable=False)
    horas= base_datos.Column(base_datos.Integer, nullable=False)
    enlace= base_datos.Column(base_datos.String(500), nullable=True)

    fotos= base_datos.relationship("Foto", backref="actividad", lazy=True, cascade="all, delete-orphan")

    def __repr__(self):
        return f"<Actividad {self.tipo} - {self.dia}>"


class Foto(base_datos.Model):
    __tablename__ = "foto"

    id= base_datos.Column(base_datos.Integer, primary_key=True, autoincrement=True)
    actividad_id= base_datos.Column(base_datos.Integer, base_datos.ForeignKey("actividad.id"), nullable=False)
    ruta_archivo= base_datos.Column(base_datos.String(300), nullable=False)  
    nombre_archivo= base_datos.Column(base_datos.String(300), nullable=False)  

    def __repr__(self):
        return f"<Foto {self.nombre_archivo}>"
