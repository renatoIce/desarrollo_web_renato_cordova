function cargarComentarios(idActividad) {
    fetch("/api/comentarios/" + idActividad)
        .then(function(respuesta) { return respuesta.json(); })
        .then(function(comentarios) {
            var contenedor = document.getElementById("comentarios-" + idActividad);
            if (comentarios.length === 0) {
                contenedor.innerHTML = "<p>No hay comentarios aún.</p>";
                return;
            }
            var html = "";
            comentarios.forEach(function(c) {
                html += "<div class='comentario-item'>";
                html += "<p><strong>" + c.nombre + "</strong> - " + c.fecha + "</p>";
                html += "<p>" + c.texto + "</p>";
                html += "</div>";
            });
            contenedor.innerHTML = html;
        })
        .catch(function() {
            document.getElementById("comentarios-" + idActividad).innerHTML = "<p>Error al cargar comentarios.</p>";
        });
}

function enviarComentario(idActividad) {
    var nombreInput = document.getElementById("nombre-comentario-" + idActividad);
    var textoInput  = document.getElementById("texto-comentario-"  + idActividad);
    var errorNombre = document.getElementById("error-nombre-comentario-" + idActividad);
    var errorTexto  = document.getElementById("error-texto-comentario-"  + idActividad);

    var nombre = nombreInput.value.trim();
    var texto  = textoInput.value.trim();

    
    errorNombre.textContent = "";
    errorTexto.textContent  = "";

    
    var valido = true;
    if (nombre.length < 3 || nombre.length > 80) {
        errorNombre.textContent = "El nombre debe tener entre 3 y 80 caracteres.";
        valido = false;
    }
    if (texto.length < 5) {
        errorTexto.textContent = "El comentario debe tener al menos 5 caracteres.";
        valido = false;
    }
    if (!valido) return;

    fetch("/api/comentarios/" + idActividad, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nombre: nombre, texto: texto })
    })
    .then(function(respuesta) { return respuesta.json(); })
    .then(function(datos) {
        if (datos.error) {
            if (datos.error.nombre) errorNombre.textContent = datos.error.nombre;
            if (datos.error.texto)  errorTexto.textContent  = datos.error.texto;
            return;
        }
        
        nombreInput.value = "";
        textoInput.value  = "";
        cargarComentarios(idActividad);
    })
    .catch(function() {
        errorTexto.textContent = "Error al enviar el comentario.";
    });
}
